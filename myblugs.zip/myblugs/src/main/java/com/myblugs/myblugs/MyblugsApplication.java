package com.myblugs.myblugs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyblugsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyblugsApplication.class, args);
	}

}
